"""Search keyboard decision. Ack means the Android IME activity opened."""
# 0.4.2: a cold Fire TV can take longer than 1.5 s to open the input activity; a late ack used to race
# the Kodi-keyboard fallback and leave the user with no keyboard at all.
FAIL_AFTER = 3.0


def files_dirs(translated_paths, packages=('com.fefc.kodi', 'org.xbmc.kodi')):
    dirs = []

    def add(d):
        d = (d or '').rstrip('/')
        if d and d not in dirs:
            dirs.append(d)

    for t in translated_paths or []:
        t = t or ''
        for pkg in packages:
            for marker in ('/Android/data/%s/files' % pkg, '/%s/files' % pkg):
                i = t.find(marker)
                if i >= 0:
                    add(t[:i + len(marker)])
    for pkg in packages:
        for root in ('/storage/emulated/0', '/sdcard'):
            add('%s/Android/data/%s/files' % (root, pkg))
    return dirs


def input_plan(platform_android, dirs, ack, elapsed, fail_after=FAIL_AFTER):
    if ack:
        return 'native'
    if not platform_android:
        # Off-Android the Kodi keyboard is the real keyboard. (The old
        # `and not dirs` clause was vacuous: get_text passes [] here
        # off-Android, and files_dirs() always returns >= 4 fallback dirs
        # on Android, so `not dirs` was unreachable on both paths.)
        return 'kodi'
    if elapsed >= fail_after:
        return 'fallback_kodi'
    return 'wait'
